// Simple script to show console message
console.log("Portfolio website for AiMayank007 loaded successfully!");
