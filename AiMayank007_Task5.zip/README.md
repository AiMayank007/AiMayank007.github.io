# AiMayank007 Portfolio Website

This is a mini portfolio website created for **Task 5 of the Web Development Internship**.  
It’s deployed for free using **GitHub Pages**.

## Features
- Responsive single-page layout  
- Sections: About, Projects, Contact  
- Simple HTML, CSS, and JS  

## Live Demo
[https://AiMayank007.github.io](https://AiMayank007.github.io)

## How to Run Locally
1. Clone the repository  
2. Open `index.html` in a browser  

---

© 2025 Mayank
